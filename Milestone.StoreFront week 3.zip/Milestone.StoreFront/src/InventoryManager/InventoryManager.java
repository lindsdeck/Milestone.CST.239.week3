package InventoryManager;

import java.util.ArrayList;
import java.util.List;
import Products.Product;
import java.util.Collections;

public class InventoryManager 
{
	private List<Product> products;
	/**
	 * 
	 */
	public InventoryManager()
	{
		products = new ArrayList<>();
		
	}
	/**
	 * Add a new product to the product list
	 */
	public void addProduct(Product product)
	{
		products.add(product);
	}
	/**
	 * REmove a product from the product list
	 */
	public void removeProduct(Product product)
	{
		products.remove(product);
	}
	/**
	 * get the product list
	 * @return
	 */
	public List<Product> getProducts()
	{
		return products;
	}
	/**
	 * 
	 */
	public void DisplayInventory()
	{
		if (products.isEmpty())
		{
			System.out.println("There is nothing in the shop today! Come back later!");
		}
		else
		{	
			//List<Product> productList = new ArrayList<>(products);
			//Collections.sort(productList);
			//products = productList;
			System.out.println(products);
			System.out.println();
			
		}
	}
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) 
	{
	

	}

}
