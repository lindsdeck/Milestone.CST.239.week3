package Products;

public class Product implements Comparable
{
	private String name;
	private String description;
	private double price;
	private int quantity;
	/**
	 * 
	 * @param name
	 * @param description
	 * @param price
	 * @param quantity
	 */
	public Product(String name, String description, double price, int quantity)
	{
		this.name = name;
		this.description = description;
		this.price = price;
		this.quantity = quantity;
	}
	/**
	 * 
	 * @return
	 */
	public double getPrice()
	{
		return price;
	}
	/**
	 * 
	 * @return
	 */
	public String getName()
	{
		return name;
	}
	/**
	 * 
	 * @return
	 */
	public int getQuantity()
	{
		return quantity;
	}
	/**
	 * 
	 * @param newQuantity
	 */
	public void updateQuantity(int newQuantity)
	{
		this.quantity = newQuantity;
	}
	
	public String toString()
	{
		return "Product: " + name + "  Description: " + description + "  Price: $" + price + "  Quanitity: " + quantity;
	}
	@Override
	public boolean compareTo(String productName)
	{
		if (this.getName().equalsIgnoreCase(productName))
		{
			return true;
		} else {
			return false;
		}
	}
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) 
	{
		

	}

}
