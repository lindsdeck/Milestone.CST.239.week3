package Products;

public class Weapon extends Product
{
	private int damage;
	private String range;
	/**
	 * 
	 * @param name
	 * @param description
	 * @param price
	 * @param quantity
	 * @param damage
	 * @param range
	 */
	public Weapon(String name, String description, double price, int quantity, int damage, String range)
	{
		super(name, description, price, quantity);
		this.damage = damage;
		this.range = range;
	}
	/**
	 * 
	 * @return
	 */
	public int getDamage()
	{
		return damage;
	}
	/**
	 * 
	 * @return
	 */
	public String range()
	{
		return range;
	}
	
	/**
	 * 
	 */
	@Override
	public String toString()
	{
		return super.toString() + "  Damage: " + damage + "  Range: " +  range + "\n";
	}
}
